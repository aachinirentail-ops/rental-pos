# Rental POS (Next.js)

Hardware rental billing system: items by category, customer ID + photo,
bills with discount, dashboard, return alerts and WhatsApp reminders.

## Run

```bash
npm install
npm run dev        # http://localhost:3000
```

For real use on the shop computer:

```bash
npm run build
npm start
```

## Where data is stored

- `data/db.json`  – items, bills, settings
- `data/uploads/` – customer ID photos

Back up the whole `data/` folder regularly.

## Pages

| Page | Purpose |
| --- | --- |
| `/` | Dashboard: income, active rentals, overdue / due-soon alerts + WhatsApp button |
| `/items` | Add / edit items, categories, rate per day, stock |
| `/billing` | New bill: items, customer, ID photo, days, discount, advance |
| `/bills` | Bill history with search and status filter |
| `/bills/[id]` | Invoice: print, send invoice / reminder on WhatsApp, mark returned |
| `/settings` | Shop name and phone |

## WhatsApp

Buttons open `wa.me/<number>?text=...` with the message already written.
You press Send yourself (manual), so no WhatsApp Business API is needed.
Numbers like `0771234567` are converted to `94771234567` automatically.

## Note

This stores data in a local JSON file, so it works on your own computer or
a VPS. It will NOT keep data on Vercel (read-only / temporary disk). If you
want to host it online later, switch `lib/db.js` to a database (Supabase,
Postgres or SQLite on a VPS).

There is no login yet. Add one before putting it on the internet.
