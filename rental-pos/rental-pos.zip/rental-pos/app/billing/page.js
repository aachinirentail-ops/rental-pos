'use client';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { money, today, addDays } from '@/lib/util';
import { useApp } from '@/components/Providers';

export default function BillingPage() {
  const { t } = useApp();
  const router = useRouter();
  const [items, setItems] = useState([]);
  const [bills, setBills] = useState([]);
  const [cat, setCat] = useState('__all');
  const [pick, setPick] = useState('');
  const [pickQty, setPickQty] = useState(1);
  const [cart, setCart] = useState([]); // {itemId, qty}

  const [customer, setCustomer] = useState({ customerName: '', phone: '', nic: '' });
  const [photo, setPhoto] = useState(null);
  const [preview, setPreview] = useState('');
  const [startDate, setStartDate] = useState(today());
  const [days, setDays] = useState(1);
  const [discountType, setDiscountType] = useState('amount');
  const [discountValue, setDiscountValue] = useState('');
  const [advance, setAdvance] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/items').then((r) => r.json()).then(setItems);
    fetch('/api/bills').then((r) => r.json()).then((d) => setBills(d.bills));
  }, []);

  const categories = [...new Set(items.map((i) => i.category))].sort();
  const pickable = items.filter((i) => (cat === '__all' || i.category === cat) && i.available > 0);

  // returning customers: autofill by phone
  const known = useMemo(() => {
    const m = new Map();
    for (const b of bills) if (!m.has(b.phone)) m.set(b.phone, b);
    return [...m.values()];
  }, [bills]);

  function useCustomer(phone) {
    const b = known.find((k) => k.phone === phone);
    if (b) setCustomer({ customerName: b.customerName, phone: b.phone, nic: b.nic });
  }

  function addToCart() {
    if (!pick) return;
    const it = items.find((i) => i.id === pick);
    const qty = Math.max(1, parseInt(pickQty, 10) || 1);
    const already = cart.find((c) => c.itemId === pick)?.qty || 0;
    if (already + qty > it.available) {
      return setError(t('billing.errOnly', { n: it.available, name: it.name }));
    }
    setError('');
    setCart((c) => {
      const ex = c.find((x) => x.itemId === pick);
      if (ex) return c.map((x) => (x.itemId === pick ? { ...x, qty: x.qty + qty } : x));
      return [...c, { itemId: pick, qty }];
    });
    setPick('');
    setPickQty(1);
  }

  const lines = cart.map((c) => ({ ...c, item: items.find((i) => i.id === c.itemId) })).filter((l) => l.item);
  const d = Math.max(1, parseInt(days, 10) || 1);
  const subtotal = lines.reduce((s, l) => s + l.qty * l.item.rate * d, 0);
  const dv = Math.max(0, Number(discountValue) || 0);
  const discountAmount = Math.min(discountType === 'percent' ? (subtotal * Math.min(dv, 100)) / 100 : dv, subtotal);
  const total = subtotal - discountAmount;
  const adv = Math.max(0, Number(advance) || 0);

  function onPhoto(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    setPhoto(f);
    setPreview(URL.createObjectURL(f));
  }

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (cart.length === 0) return setError(t('billing.errNoItem'));
    setSaving(true);
    try {
      let idPhoto = '';
      if (photo) {
        const fd = new FormData();
        fd.append('file', photo);
        const up = await fetch('/api/upload', { method: 'POST', body: fd });
        const upData = await up.json();
        if (!up.ok) throw new Error(upData.error || t('billing.errPhoto'));
        idPhoto = upData.name;
      }
      const res = await fetch('/api/bills', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...customer,
          idPhoto,
          items: cart,
          startDate,
          days: d,
          discountType,
          discountValue: dv,
          advance: adv,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || t('billing.errBill'));
      router.push('/bills/' + data.id);
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  }

  return (
    <>
      <h1>{t('billing.title')}</h1>
      <form onSubmit={submit}>
        <div className="grid two">
          <div className="card">
            <h2>{t('billing.step1')}</h2>
            <div className="chips">
              <button type="button" className={'chip' + (cat === '__all' ? ' on' : '')} onClick={() => { setCat('__all'); setPick(''); }}>
                {t('common.all')}
              </button>
              {categories.map((c) => (
                <button type="button" key={c} className={'chip' + (cat === c ? ' on' : '')} onClick={() => { setCat(c); setPick(''); }}>
                  {c}
                </button>
              ))}
            </div>
            <div className="row">
              <div style={{ flex: 3 }}>
                <label>{t('common.item')}</label>
                <select value={pick} onChange={(e) => setPick(e.target.value)}>
                  <option value="">{t('billing.selectItem')}</option>
                  {pickable.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} — {money(i.rate)} ({t('billing.availableN', { n: i.available })})
                    </option>
                  ))}
                </select>
              </div>
              <div style={{ flex: 1 }}>
                <label>{t('common.qty')}</label>
                <input type="number" min="1" value={pickQty} onChange={(e) => setPickQty(e.target.value)} />
              </div>
              <button type="button" className="btn" style={{ flex: 'none' }} onClick={addToCart}>{t('common.add')}</button>
            </div>

            <div className="table-wrap" style={{ marginTop: 14 }}>
              <table>
                <thead>
                  <tr>
                    <th>{t('common.item')}</th>
                    <th>{t('common.qty')}</th>
                    <th>{t('common.rate')}</th>
                    <th className="right">{t('common.amount')}</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {lines.length === 0 && <tr><td colSpan="5" className="muted">{t('billing.noItems')}</td></tr>}
                  {lines.map((l) => (
                    <tr key={l.itemId}>
                      <td>{l.item.name}</td>
                      <td>{l.qty}</td>
                      <td>{money(l.item.rate)}</td>
                      <td className="right">{money(l.qty * l.item.rate * d)}</td>
                      <td className="right">
                        <button type="button" className="btn danger small" onClick={() => setCart(cart.filter((c) => c.itemId !== l.itemId))}>✕</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="card">
            <h2>{t('billing.step2')}</h2>
            {known.length > 0 && (
              <>
                <label>{t('billing.returning')}</label>
                <select value="" onChange={(e) => e.target.value && useCustomer(e.target.value)}>
                  <option value="">{t('billing.pickPrev')}</option>
                  {known.map((k) => (
                    <option key={k.phone} value={k.phone}>{k.customerName} — {k.phone}</option>
                  ))}
                </select>
              </>
            )}
            <label>{t('billing.custName')}</label>
            <input required value={customer.customerName} onChange={(e) => setCustomer({ ...customer, customerName: e.target.value })} />
            <label>{t('billing.waNumber')}</label>
            <input required inputMode="tel" placeholder="0771234567" value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} />
            <label>{t('billing.nicNumber')}</label>
            <input required value={customer.nic} onChange={(e) => setCustomer({ ...customer, nic: e.target.value })} />
            <label>{t('billing.idPhoto')}</label>
            <input type="file" accept="image/*" capture="environment" onChange={onPhoto} />
            {preview && <img className="idphoto" src={preview} alt="ID" />}
          </div>
        </div>

        <div className="card" style={{ marginTop: 14 }}>
          <h2>{t('billing.step3')}</h2>
          <div className="row">
            <div>
              <label>{t('billing.startDate')}</label>
              <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            </div>
            <div>
              <label>{t('billing.numDays')}</label>
              <input type="number" min="1" value={days} onChange={(e) => setDays(e.target.value)} />
            </div>
            <div>
              <label>{t('billing.returnDate')}</label>
              <input value={addDays(startDate, d)} readOnly />
            </div>
          </div>
          <div className="row">
            <div>
              <label>{t('billing.discType')}</label>
              <select value={discountType} onChange={(e) => setDiscountType(e.target.value)}>
                <option value="amount">{t('billing.amountRs')}</option>
                <option value="percent">{t('billing.percent')}</option>
              </select>
            </div>
            <div>
              <label>{t('billing.discount')}</label>
              <input type="number" min="0" step="0.01" value={discountValue} onChange={(e) => setDiscountValue(e.target.value)} />
            </div>
            <div>
              <label>{t('billing.advanceRs')}</label>
              <input type="number" min="0" step="0.01" value={advance} onChange={(e) => setAdvance(e.target.value)} />
            </div>
          </div>
          <label>{t('billing.notes')}</label>
          <textarea rows="2" value={notes} onChange={(e) => setNotes(e.target.value)} />

          <div className="totals">
            <div><span>{t('billing.subtotalDays', { d })}</span><span>{money(subtotal)}</span></div>
            <div><span>{t('common.discount')}</span><span>- {money(discountAmount)}</span></div>
            <div className="grand"><span>{t('common.total')}</span><span>{money(total)}</span></div>
            <div><span>{t('common.advance')}</span><span>{money(adv)}</span></div>
            <div><span>{t('common.balance')}</span><span>{money(Math.max(0, total - adv))}</span></div>
          </div>

          {error && <div className="error">{error}</div>}
          <button className="btn" style={{ marginTop: 14, width: '100%', padding: 14, fontSize: 16 }} disabled={saving}>
            {saving ? t('billing.saving') : t('billing.create')}
          </button>
        </div>
      </form>
    </>
  );
}
