'use client';
import { useEffect, useState } from 'react';
import { useApp } from '@/components/Providers';

export default function SettingsPage() {
  const { t } = useApp();
  const [s, setS] = useState({ shopName: '', shopPhone: '' });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch('/api/settings').then((r) => r.json()).then(setS);
  }, []);

  async function save(e) {
    e.preventDefault();
    await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(s),
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <>
      <h1>{t('settings.title')}</h1>
      <form className="card" onSubmit={save} style={{ maxWidth: 480 }}>
        <label>{t('settings.shopName')}</label>
        <input required value={s.shopName} onChange={(e) => setS({ ...s, shopName: e.target.value })} />
        <label>{t('settings.shopPhone')}</label>
        <input value={s.shopPhone} onChange={(e) => setS({ ...s, shopPhone: e.target.value })} />
        <button className="btn" style={{ marginTop: 14 }}>{t('common.save')}</button>
        {saved && <span style={{ marginLeft: 12, color: 'var(--ok)' }}>{t('settings.saved')}</span>}
      </form>
    </>
  );
}
