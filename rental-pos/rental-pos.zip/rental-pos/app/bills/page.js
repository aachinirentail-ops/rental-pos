'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { money, dueInfo, waLink, reminderText } from '@/lib/util';
import { useApp } from '@/components/Providers';

export default function BillsPage() {
  const { t, lang } = useApp();
  const [bills, setBills] = useState([]);
  const [shop, setShop] = useState('My Rental Shop');
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');

  async function load() {
    const d = await fetch('/api/bills').then((r) => r.json());
    setBills(d.bills);
    setShop(d.settings.shopName);
  }
  useEffect(() => {
    load();
  }, []);

  async function act(id, action) {
    if (action === 'return' && !confirm(t('common.confirmReturn'))) return;
    await fetch('/api/bills', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, action }),
    });
    load();
  }

  const rows = bills
    .map((b) => ({ b, info: dueInfo(b) }))
    .filter(({ b, info }) => {
      if (status === 'returned' && b.status !== 'returned') return false;
      if (status === 'active' && b.status !== 'active') return false;
      if (status === 'overdue' && info.state !== 'overdue') return false;
      const s = q.trim().toLowerCase();
      if (!s) return true;
      return [b.billNo, b.customerName, b.phone, b.nic].some((v) => String(v).toLowerCase().includes(s));
    });

  const total = rows.reduce((s, r) => s + r.b.total, 0);

  return (
    <>
      <h1>{t('history.title')}</h1>
      <div className="card" style={{ marginBottom: 14 }}>
        <div className="row">
          <div style={{ flex: 3 }}>
            <label>{t('history.search')}</label>
            <input value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div>
            <label>{t('common.status')}</label>
            <select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="all">{t('common.all')}</option>
              <option value="active">{t('status.active')}</option>
              <option value="overdue">{t('status.overdue')}</option>
              <option value="returned">{t('status.returned')}</option>
            </select>
          </div>
        </div>
        <p className="muted" style={{ marginBottom: 0 }}>
          {t('history.count', { n: rows.length, total: money(total) })}
        </p>
      </div>

      <div className="card table-wrap">
        <table>
          <thead>
            <tr>
              <th>{t('common.bill')}</th>
              <th>{t('common.date')}</th>
              <th>{t('common.customer')}</th>
              <th>NIC</th>
              <th>{t('common.items')}</th>
              <th>{t('common.due')}</th>
              <th className="right">{t('common.total')}</th>
              <th>{t('common.status')}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan="9" className="muted">{t('history.none')}</td></tr>}
            {rows.map(({ b, info }) => (
              <tr key={b.id}>
                <td><Link href={`/bills/${b.id}`}><b>{b.billNo}</b></Link></td>
                <td>{b.startDate}</td>
                <td>{b.customerName}<div className="muted">{b.phone}</div></td>
                <td>{b.nic}</td>
                <td>{b.items.map((i) => `${i.name} x${i.qty}`).join(', ')}</td>
                <td>{b.dueDate}</td>
                <td className="right">{money(b.total)}</td>
                <td><span className={'badge ' + info.state}>{t('status.' + info.state)}</span></td>
                <td className="right" style={{ whiteSpace: 'nowrap' }}>
                  {b.status === 'active' ? (
                    <>
                      <a className="btn wa small" target="_blank" rel="noreferrer" href={waLink(b.phone, reminderText(b, shop, lang))}>{t('common.whatsapp')}</a>{' '}
                      <button className="btn sec small" onClick={() => act(b.id, 'return')}>{t('common.returned')}</button>
                    </>
                  ) : (
                    <button className="btn sec small" onClick={() => act(b.id, 'reopen')}>{t('common.reopen')}</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
