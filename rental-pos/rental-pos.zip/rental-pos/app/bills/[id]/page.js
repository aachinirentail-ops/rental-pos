'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { money, dueInfo, waLink, reminderText, invoiceText } from '@/lib/util';
import { useApp } from '@/components/Providers';

export default function InvoicePage() {
  const { t, lang } = useApp();
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');

  async function load() {
    const res = await fetch('/api/bills?id=' + id);
    const d = await res.json();
    if (!res.ok) return setErr(t('invoice.notFound'));
    setData(d);
  }
  useEffect(() => {
    load();
  }, [id]);

  async function markReturned() {
    if (!confirm(t('common.confirmReturn'))) return;
    await fetch('/api/bills', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, action: 'return' }),
    });
    load();
  }

  if (err) return <p className="error">{err}</p>;
  if (!data) return <p className="muted">{t('common.loading')}</p>;

  const { bill: b, settings } = data;
  const info = dueInfo(b);
  const balance = Math.max(0, b.total - (b.advance || 0));

  return (
    <>
      <div className="actions">
        <button className="btn" onClick={() => window.print()}>{t('common.print')}</button>
        <a className="btn wa" target="_blank" rel="noreferrer" href={waLink(b.phone, invoiceText(b, settings.shopName, lang))}>
          {t('invoice.sendInvoice')}
        </a>
        {b.status === 'active' && (
          <a className="btn wa" target="_blank" rel="noreferrer" href={waLink(b.phone, reminderText(b, settings.shopName, lang))}>
            {t('invoice.sendReminder')}
          </a>
        )}
        {b.status === 'active' && <button className="btn sec" onClick={markReturned}>{t('invoice.markReturned')}</button>}
        <Link className="btn sec" href="/billing">{t('invoice.newBill')}</Link>
      </div>

      <div className="invoice">
        <h1>{settings.shopName}</h1>
        {settings.shopPhone && <p style={{ textAlign: 'center', margin: 0 }} className="muted">{settings.shopPhone}</p>}
        <hr />
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
          <div>
            <b>{t('invoice.billNo', { no: b.billNo })}</b>
            <div className="muted">{new Date(b.createdAt).toLocaleString('en-LK', { timeZone: 'Asia/Colombo' })}</div>
          </div>
          <span className={'badge ' + info.state}>{t('status.' + info.state)}</span>
        </div>

        <p>
          <b>{b.customerName}</b><br />
          {b.phone}<br />
          NIC: {b.nic || '-'}
        </p>

        <table>
          <thead>
            <tr>
              <th>{t('common.item')}</th>
              <th>{t('common.qty')}</th>
              <th>{t('invoice.rateDay')}</th>
              <th className="right">{t('common.amount')}</th>
            </tr>
          </thead>
          <tbody>
            {b.items.map((i) => (
              <tr key={i.itemId}>
                <td>{i.name}</td>
                <td>{i.qty}</td>
                <td>{money(i.rate)}</td>
                <td className="right">{money(i.qty * i.rate * b.days)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <p className="muted">
          {t('invoice.rental')}: {b.startDate} → {b.dueDate} ({b.days})
        </p>

        <div className="totals">
          <div><span>{t('common.subtotal')}</span><span>{money(b.subtotal)}</span></div>
          {b.discountAmount > 0 && (
            <div>
              <span>{b.discountType === 'percent' ? t('invoice.discountPct', { v: b.discountValue }) : t('common.discount')}</span>
              <span>- {money(b.discountAmount)}</span>
            </div>
          )}
          <div className="grand"><span>{t('common.total')}</span><span>{money(b.total)}</span></div>
          <div><span>{t('common.advance')}</span><span>{money(b.advance)}</span></div>
          <div><span>{t('common.balance')}</span><span>{money(balance)}</span></div>
        </div>

        {b.notes && <p className="muted">{t('billing.notes').replace(/\s*\(.*\)$/, '')}: {b.notes}</p>}

        {b.idPhoto && (
          <div className="noprint">
            <p className="muted" style={{ marginBottom: 0 }}>{t('invoice.idPhoto')}</p>
            <img className="idphoto" src={'/api/uploads/' + b.idPhoto} alt="ID" />
          </div>
        )}
        <p style={{ textAlign: 'center', marginTop: 24 }}>{t('common.thankYou')}</p>
      </div>
    </>
  );
}
