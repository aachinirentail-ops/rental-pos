import { NextResponse } from 'next/server';
import { readDb, writeDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json(readDb().settings);
}

export async function PUT(req) {
  const body = await req.json();
  const db = readDb();
  db.settings = {
    shopName: String(body.shopName || db.settings.shopName).trim(),
    shopPhone: String(body.shopPhone ?? db.settings.shopPhone).trim(),
  };
  writeDb(db);
  return NextResponse.json(db.settings);
}
