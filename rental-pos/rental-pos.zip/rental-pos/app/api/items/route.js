import { NextResponse } from 'next/server';
import { readDb, writeDb, newId } from '@/lib/db';

export const dynamic = 'force-dynamic';

function withAvailability(db) {
  const out = {};
  for (const b of db.bills) {
    if (b.status !== 'active') continue;
    for (const i of b.items) out[i.itemId] = (out[i.itemId] || 0) + i.qty;
  }
  return db.items.map((it) => ({
    ...it,
    rented: out[it.id] || 0,
    available: Math.max(0, it.stock - (out[it.id] || 0)),
  }));
}

export async function GET() {
  const db = readDb();
  return NextResponse.json(withAvailability(db));
}

export async function POST(req) {
  const body = await req.json();
  if (!body.name || !body.category) {
    return NextResponse.json({ error: 'Name and category are required' }, { status: 400 });
  }
  const db = readDb();
  const item = {
    id: newId(),
    name: String(body.name).trim(),
    category: String(body.category).trim(),
    rate: Number(body.rate) || 0,
    stock: Math.max(0, parseInt(body.stock, 10) || 0),
  };
  db.items.push(item);
  writeDb(db);
  return NextResponse.json(item);
}

export async function PUT(req) {
  const body = await req.json();
  const db = readDb();
  const it = db.items.find((x) => x.id === body.id);
  if (!it) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  it.name = String(body.name ?? it.name).trim();
  it.category = String(body.category ?? it.category).trim();
  it.rate = Number(body.rate ?? it.rate) || 0;
  it.stock = Math.max(0, parseInt(body.stock ?? it.stock, 10) || 0);
  writeDb(db);
  return NextResponse.json(it);
}

export async function DELETE(req) {
  const id = new URL(req.url).searchParams.get('id');
  const db = readDb();
  const inUse = db.bills.some((b) => b.status === 'active' && b.items.some((i) => i.itemId === id));
  if (inUse) {
    return NextResponse.json({ error: 'This item is currently rented out' }, { status: 400 });
  }
  db.items = db.items.filter((x) => x.id !== id);
  writeDb(db);
  return NextResponse.json({ ok: true });
}
