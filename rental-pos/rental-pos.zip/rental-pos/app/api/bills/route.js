import { NextResponse } from 'next/server';
import { readDb, writeDb, newId } from '@/lib/db';
import { addDays, today } from '@/lib/util';

export const dynamic = 'force-dynamic';

export async function GET(req) {
  const id = new URL(req.url).searchParams.get('id');
  const db = readDb();
  if (id) {
    const bill = db.bills.find((b) => b.id === id);
    if (!bill) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({ bill, settings: db.settings });
  }
  const bills = [...db.bills].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return NextResponse.json({ bills, settings: db.settings });
}

export async function POST(req) {
  const body = await req.json();
  const db = readDb();

  if (!body.customerName || !body.phone) {
    return NextResponse.json({ error: 'Customer name and phone are required' }, { status: 400 });
  }
  if (!Array.isArray(body.items) || body.items.length === 0) {
    return NextResponse.json({ error: 'Add at least one item' }, { status: 400 });
  }
  const days = Math.max(1, parseInt(body.days, 10) || 1);

  // rented count per item right now
  const rented = {};
  for (const b of db.bills) {
    if (b.status !== 'active') continue;
    for (const i of b.items) rented[i.itemId] = (rented[i.itemId] || 0) + i.qty;
  }

  const lines = [];
  for (const row of body.items) {
    const it = db.items.find((x) => x.id === row.itemId);
    if (!it) return NextResponse.json({ error: 'Item not found' }, { status: 400 });
    const qty = Math.max(1, parseInt(row.qty, 10) || 1);
    const free = it.stock - (rented[it.id] || 0);
    if (qty > free) {
      return NextResponse.json(
        { error: `Only ${free} of "${it.name}" available` },
        { status: 400 }
      );
    }
    lines.push({ itemId: it.id, name: it.name, category: it.category, qty, rate: it.rate });
  }

  const subtotal = lines.reduce((s, l) => s + l.qty * l.rate * days, 0);
  const dType = body.discountType === 'percent' ? 'percent' : 'amount';
  const dValue = Math.max(0, Number(body.discountValue) || 0);
  let discountAmount = dType === 'percent' ? (subtotal * Math.min(dValue, 100)) / 100 : dValue;
  discountAmount = Math.min(discountAmount, subtotal);
  const total = subtotal - discountAmount;

  db.counter += 1;
  const startDate = body.startDate || today();
  const bill = {
    id: newId(),
    billNo: 'R-' + String(db.counter).padStart(4, '0'),
    customerName: String(body.customerName).trim(),
    phone: String(body.phone).trim(),
    nic: String(body.nic || '').trim(),
    idPhoto: body.idPhoto || '',
    items: lines,
    startDate,
    days,
    dueDate: addDays(startDate, days),
    subtotal,
    discountType: dType,
    discountValue: dValue,
    discountAmount,
    total,
    advance: Math.max(0, Number(body.advance) || 0),
    notes: String(body.notes || ''),
    status: 'active',
    createdAt: new Date().toISOString(),
    returnedAt: null,
  };
  db.bills.push(bill);
  writeDb(db);
  return NextResponse.json(bill);
}

// mark a bill as returned (or re-open it)
export async function PATCH(req) {
  const { id, action } = await req.json();
  const db = readDb();
  const bill = db.bills.find((b) => b.id === id);
  if (!bill) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  if (action === 'return') {
    bill.status = 'returned';
    bill.returnedAt = new Date().toISOString();
  } else if (action === 'reopen') {
    bill.status = 'active';
    bill.returnedAt = null;
  }
  writeDb(db);
  return NextResponse.json(bill);
}
