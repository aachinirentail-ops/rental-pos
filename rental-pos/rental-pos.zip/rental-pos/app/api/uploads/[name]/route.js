import fs from 'fs';
import path from 'path';
import { UPLOAD_DIR } from '@/lib/db';

export const dynamic = 'force-dynamic';

const TYPES = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };

export async function GET(_req, { params }) {
  const name = path.basename(params.name); // blocks ../ tricks
  const file = path.join(UPLOAD_DIR, name);
  if (!fs.existsSync(file)) return new Response('Not found', { status: 404 });
  const ext = name.split('.').pop().toLowerCase();
  return new Response(fs.readFileSync(file), {
    headers: { 'Content-Type': TYPES[ext] || 'application/octet-stream' },
  });
}
