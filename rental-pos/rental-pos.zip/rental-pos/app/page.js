'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { money, today, dueInfo, waLink, reminderText } from '@/lib/util';
import { useApp } from '@/components/Providers';

export default function Dashboard() {
  const { t, lang } = useApp();
  const [bills, setBills] = useState([]);
  const [items, setItems] = useState([]);
  const [shop, setShop] = useState('My Rental Shop');
  const [loading, setLoading] = useState(true);

  async function load() {
    const [b, i] = await Promise.all([
      fetch('/api/bills').then((r) => r.json()),
      fetch('/api/items').then((r) => r.json()),
    ]);
    setBills(b.bills);
    setShop(b.settings.shopName);
    setItems(i);
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, []);

  async function markReturned(id) {
    if (!confirm(t('common.confirmReturn'))) return;
    await fetch('/api/bills', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, action: 'return' }),
    });
    load();
  }

  if (loading) return <p className="muted">{t('common.loading')}</p>;

  const day = today();
  const month = day.slice(0, 7);
  const active = bills.filter((b) => b.status === 'active');
  const alerts = active
    .map((b) => ({ b, info: dueInfo(b) }))
    .filter((x) => ['overdue', 'due-today', 'due-tomorrow'].includes(x.info.state))
    .sort((a, b) => a.b.dueDate.localeCompare(b.b.dueDate));
  const overdue = alerts.filter((x) => x.info.state === 'overdue').length;
  const dueSoon = alerts.length - overdue;

  // createdAt is UTC ISO; shift to Sri Lanka time for the day/month buckets
  const local = (iso) => new Date(new Date(iso).getTime() + 5.5 * 3600 * 1000).toISOString().slice(0, 10);
  const todayIncome = bills.filter((b) => local(b.createdAt) === day).reduce((s, b) => s + b.total, 0);
  const monthIncome = bills.filter((b) => local(b.createdAt).startsWith(month)).reduce((s, b) => s + b.total, 0);
  const soldOut = items.filter((i) => i.available === 0);

  return (
    <>
      <h1>{t('dash.title')}</h1>

      <div className="grid stats">
        <div className="card stat"><div className="label">{t('dash.todayIncome')}</div><div className="value">{money(todayIncome)}</div></div>
        <div className="card stat"><div className="label">{t('dash.monthIncome')}</div><div className="value">{money(monthIncome)}</div></div>
        <div className="card stat"><div className="label">{t('dash.activeRentals')}</div><div className="value">{active.length}</div></div>
        <div className="card stat danger"><div className="label">{t('dash.overdue')}</div><div className="value">{overdue}</div></div>
        <div className="card stat warn"><div className="label">{t('dash.dueSoon')}</div><div className="value">{dueSoon}</div></div>
        <div className="card stat"><div className="label">{t('dash.totalBills')}</div><div className="value">{bills.length}</div></div>
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <h2>{t('dash.alerts')}</h2>
        {alerts.length === 0 ? (
          <p className="muted">{t('dash.noAlerts')}</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>{t('common.bill')}</th>
                  <th>{t('common.customer')}</th>
                  <th>{t('common.items')}</th>
                  <th>{t('common.due')}</th>
                  <th>{t('common.status')}</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {alerts.map(({ b, info }) => (
                  <tr key={b.id}>
                    <td><Link href={`/bills/${b.id}`}><b>{b.billNo}</b></Link></td>
                    <td>{b.customerName}<div className="muted">{b.phone}</div></td>
                    <td>{b.items.map((i) => `${i.name} x${i.qty}`).join(', ')}</td>
                    <td>{b.dueDate}</td>
                    <td>
                      <span className={'badge ' + info.state}>
                        {t('status.' + info.state)}
                        {info.state === 'overdue' ? ` (${info.days}${t('dash.daysShort')})` : ''}
                      </span>
                    </td>
                    <td className="right" style={{ whiteSpace: 'nowrap' }}>
                      <a
                        className="btn wa small"
                        href={waLink(b.phone, reminderText(b, shop, lang))}
                        target="_blank"
                        rel="noreferrer"
                      >
                        {t('common.whatsapp')}
                      </a>{' '}
                      <button className="btn sec small" onClick={() => markReturned(b.id)}>{t('common.returned')}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="grid two">
        <div className="card">
          <h2>{t('dash.outOfStock')}</h2>
          {soldOut.length === 0 ? (
            <p className="muted">{t('dash.allInStock')}</p>
          ) : (
            soldOut.map((i) => (
              <div key={i.id} style={{ padding: '6px 0' }}>
                {i.name} <span className="muted">({i.category})</span>
              </div>
            ))
          )}
        </div>
        <div className="card">
          <h2>{t('dash.quick')}</h2>
          <div className="actions" style={{ justifyContent: 'flex-start' }}>
            <Link className="btn" href="/billing">{t('dash.newBill')}</Link>
            <Link className="btn sec" href="/items">{t('dash.manageItems')}</Link>
            <Link className="btn sec" href="/bills">{t('nav.billHistory')}</Link>
          </div>
        </div>
      </div>
    </>
  );
}
