'use client';
import { useEffect, useState } from 'react';
import { money } from '@/lib/util';
import { useApp } from '@/components/Providers';

const EMPTY = { name: '', category: '', rate: '', stock: '' };

export default function ItemsPage() {
  const { t } = useApp();
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editId, setEditId] = useState(null);
  const [filter, setFilter] = useState('__all');
  const [error, setError] = useState('');

  async function load() {
    setItems(await fetch('/api/items').then((r) => r.json()));
  }
  useEffect(() => {
    load();
  }, []);

  const categories = [...new Set(items.map((i) => i.category))].sort();

  async function save(e) {
    e.preventDefault();
    setError('');
    const res = await fetch('/api/items', {
      method: editId ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editId ? { ...form, id: editId } : form),
    });
    const data = await res.json();
    if (!res.ok) return setError(data.error || t('items.failedSave'));
    setForm(EMPTY);
    setEditId(null);
    load();
  }

  function edit(it) {
    setEditId(it.id);
    setForm({ name: it.name, category: it.category, rate: it.rate, stock: it.stock });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function remove(it) {
    if (!confirm(t('items.confirmDelete', { name: it.name }))) return;
    const res = await fetch('/api/items?id=' + it.id, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) return alert(data.error);
    load();
  }

  const shown = filter === '__all' ? items : items.filter((i) => i.category === filter);

  return (
    <>
      <h1>{t('items.title')}</h1>

      <form className="card" onSubmit={save} style={{ marginBottom: 20 }}>
        <h2>{editId ? t('items.editItem') : t('items.addItem')}</h2>
        <div className="row">
          <div>
            <label>{t('items.name')}</label>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label>{t('common.category')}</label>
            <input required list="cats" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
            <datalist id="cats">{categories.map((c) => <option key={c} value={c} />)}</datalist>
          </div>
          <div>
            <label>{t('items.ratePerDay')}</label>
            <input required type="number" min="0" step="0.01" value={form.rate} onChange={(e) => setForm({ ...form, rate: e.target.value })} />
          </div>
          <div>
            <label>{t('items.stock')}</label>
            <input required type="number" min="0" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
          </div>
        </div>
        {error && <div className="error">{error}</div>}
        <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
          <button className="btn" type="submit">{editId ? t('items.update') : t('items.addItem')}</button>
          {editId && (
            <button type="button" className="btn sec" onClick={() => { setEditId(null); setForm(EMPTY); }}>
              {t('common.cancel')}
            </button>
          )}
        </div>
      </form>

      <div className="card">
        <div className="chips">
          <button className={'chip' + (filter === '__all' ? ' on' : '')} onClick={() => setFilter('__all')}>
            {t('common.all')}
          </button>
          {categories.map((c) => (
            <button key={c} className={'chip' + (filter === c ? ' on' : '')} onClick={() => setFilter(c)}>
              {c}
            </button>
          ))}
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>{t('common.item')}</th>
                <th>{t('common.category')}</th>
                <th>{t('items.rateCol')}</th>
                <th>{t('items.stockCol')}</th>
                <th>{t('items.rented')}</th>
                <th>{t('items.available')}</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {shown.length === 0 && (
                <tr><td colSpan="7" className="muted">{t('items.empty')}</td></tr>
              )}
              {shown.map((it) => (
                <tr key={it.id}>
                  <td><b>{it.name}</b></td>
                  <td>{it.category}</td>
                  <td>{money(it.rate)}</td>
                  <td>{it.stock}</td>
                  <td>{it.rented}</td>
                  <td style={{ color: it.available === 0 ? 'var(--danger)' : 'inherit', fontWeight: 600 }}>{it.available}</td>
                  <td className="right" style={{ whiteSpace: 'nowrap' }}>
                    <button className="btn sec small" onClick={() => edit(it)}>{t('common.edit')}</button>{' '}
                    <button className="btn danger small" onClick={() => remove(it)}>{t('common.delete')}</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
